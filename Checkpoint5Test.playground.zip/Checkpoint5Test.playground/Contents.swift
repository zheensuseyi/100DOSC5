// Zheen H. Suseyi
// 09/19/2024
// Checkpoint 5

/*
Your input is this:

let luckyNumbers = [7, 4, 38, 21, 16, 15, 12, 33, 31, 49]
Your job is to:

Filter out any numbers that are even
Sort the array in ascending order
Map them to strings in the format “7 is a lucky number”
Print the resulting array, one item per line
*/

import UIKit

// inital unsorted array
let luckyNumbers = [7, 4, 38, 21, 16, 15, 12, 33, 31, 49]

// copying the unsorted array into a new sorted one
var ascendedNumbers = luckyNumbers.sorted()

// printing it to make sure it worked
print(ascendedNumbers)

// function to remove all even numbers out of an array, takes an int array as a parameter and returns an int array
func noEven(arr: [Int]) -> [Int] {
    // creating an empty array
    var oddArr: [Int] = []
    // iterating thru the parameter array
    for nums in arr{
        // formula to get the even numbers out
        if nums % 2 != 0{
            // adding the odd number to our new array
            oddArr.append(nums)
        }
    }
    // returning our new array
    return oddArr
}

// testing our new function and filling out a new array
let oddNumbers = noEven(arr: ascendedNumbers)
// printing the results
print(oddNumbers)

// another new function that will turn an array of ints into an array of strings that prints out an expression
func stringNumber(arr: [Int]) -> [String] {
    // new empty string array
    var stringArr: [String] = []
    // iterating thru it
    for num in arr {
        // if number is odd then its a lucky number
        if num % 2 != 0 {
            // adding the number plus an expression to a new array
            stringArr.append("\(num) is a lucky number")
            // new line to make the print statement a little neater
            print(" ")
        }
    }
    // returning the new array
    return stringArr
}

// making our last array that is sorted in ascending order, and only contains odd lucky numbers.
let finalNumbers = stringNumber(arr: oddNumbers)
// printing it
print(finalNumbers)


